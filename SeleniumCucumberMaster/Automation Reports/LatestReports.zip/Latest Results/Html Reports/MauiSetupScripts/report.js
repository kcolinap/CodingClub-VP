$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("MauiSetups.feature");
formatter.feature({
  "line": 1,
  "name": "Create Setups",
  "description": "",
  "id": "create-setups",
  "keyword": "Feature"
});
formatter.before({
  "duration": 3196186453,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Run scripts to add all valid setups",
  "description": "",
  "id": "create-setups;run-scripts-to-add-all-valid-setups",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "Navigate to Mauiqa1",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "I login as HRADMIN",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "I use the Data Provided to run Workers Compensation setup script:",
  "rows": [
    {
      "cells": [
        "testcase",
        "state",
        "code",
        "name",
        "nameedit",
        "rate",
        "rateedit",
        "alt1",
        "alt2"
      ],
      "line": 7
    },
    {
      "cells": [
        "All valid inputs, three number code and AlphaNum name, two decimal rate",
        "identifier-AL",
        "123",
        "QAcode1",
        "QAcode1edit",
        "0.01",
        "0.02",
        "//a[contains(text(),\u0027123\u0027)]",
        "List Workers\u0027 Comp Codes",
        ""
      ],
      "line": 8
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "MauiSetups.navigate_to_AscentisHome_site()"
});
formatter.result({
  "duration": 1778800689,
  "status": "passed"
});
formatter.match({
  "location": "MauiSetups.I_login_as_HRADMIN()"
});
formatter.result({
  "duration": 11821182379,
  "error_message": "java.lang.AssertionError: Exception occured while entering login details into Ascentis home pageUnable to locate element: {\"method\":\"id\",\"selector\":\"Image2\"}\nCommand duration or timeout: 11.74 seconds\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00272.46.0\u0027, revision: \u002761506a4624b13675f24581e453592342b7485d71\u0027, time: \u00272015-06-04 10:22:50\u0027\nSystem info: host: \u0027shiggins-latop\u0027, ip: \u0027192.168.7.4\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.firefox.FirefoxDriver\nCapabilities [{applicationCacheEnabled\u003dtrue, rotatable\u003dfalse, handlesAlerts\u003dtrue, databaseEnabled\u003dtrue, version\u003d39.0, platform\u003dWINDOWS, nativeEvents\u003dfalse, acceptSslCerts\u003dtrue, webStorageEnabled\u003dtrue, locationContextEnabled\u003dtrue, browserName\u003dfirefox, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue}]\nSession ID: aea40477-670b-46c9-89b9-8704c3957a2f\n*** Element info: {Using\u003did, value\u003dImage2}\r\n\tat org.junit.Assert.fail(Assert.java:93)\r\n\tat abstracts.Login.login_propfiles(Login.java:277)\r\n\tat stepDefs.MauiSetupScripts.MauiSetups.I_login_as_HRADMIN(MauiSetups.java:106)\r\n\tat ✽.Then I login as HRADMIN(MauiSetups.feature:5)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "MauiSetups.I_use_the_Data_Provided_to_run_Compensation_setup_script(String,String\u003e\u003e)"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded0.png");
formatter.after({
  "duration": 412890880,
  "status": "passed"
});
});